import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project1.settings')

import django
django.setup()

from app1.models import Student

from faker import Faker
from random import randint

fake = Faker()

def populate(value):
    for i in range(value):
        fern = randint(1001,1999)
        ffname = fake.name()
        flname = fake.name()
        fmarks =  randint(1001,1999)
        stu_records = Student.objects.get_or_create(rn=fern, fname=ffname, lname=flname, marks=fmarks)

def main():
    no = int(input("Enter how many records you wnat to create"))
    populate(no)

if __name__ == "__main__":
    main()