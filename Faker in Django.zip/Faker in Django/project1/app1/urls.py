from django.urls import path
from app1.views import studentview

urlpatterns = [
    path('sv/',studentview)
]