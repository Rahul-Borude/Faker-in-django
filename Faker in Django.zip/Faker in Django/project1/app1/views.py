from django.shortcuts import render
from app1.models import Student
from app1.forms import StudentForm
# Create your views here.

def studentview(request):
    obj = Student.objects.all()
    template_name = "app1/showstudent.html"
    context = {'student':obj}
    return render(request, template_name, context)